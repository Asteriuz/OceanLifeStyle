namespace GS.Models.Comum;

public class IModel
{
    int Id { get; set; }
}