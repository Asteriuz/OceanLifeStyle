package br.com.fiap.oceanstyle.dto.estado;

public record CadastroEstadoDTO(
        String nome,
        String sigla) {
}
