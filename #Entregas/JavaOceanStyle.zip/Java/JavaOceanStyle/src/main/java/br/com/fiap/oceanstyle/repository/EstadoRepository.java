package br.com.fiap.oceanstyle.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.fiap.oceanstyle.model.Estado;

public interface EstadoRepository extends JpaRepository<Estado, Long> {

}
