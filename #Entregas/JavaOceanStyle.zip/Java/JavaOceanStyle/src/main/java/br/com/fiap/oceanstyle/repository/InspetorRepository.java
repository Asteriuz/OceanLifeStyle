package br.com.fiap.oceanstyle.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.fiap.oceanstyle.model.Inspetor;

public interface InspetorRepository extends JpaRepository<Inspetor, Long> {

}
